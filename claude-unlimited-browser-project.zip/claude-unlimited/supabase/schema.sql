-- Run this in Supabase Dashboard → SQL Editor.
create table if not exists public.conversations (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'New conversation',
  messages jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.conversations enable row level security;

revoke all on table public.conversations from anon;
grant select, insert, update, delete on table public.conversations to authenticated;

drop policy if exists "Users can read their own conversations" on public.conversations;
create policy "Users can read their own conversations"
on public.conversations for select to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "Users can create their own conversations" on public.conversations;
create policy "Users can create their own conversations"
on public.conversations for insert to authenticated
with check ((select auth.uid()) = user_id);

drop policy if exists "Users can update their own conversations" on public.conversations;
create policy "Users can update their own conversations"
on public.conversations for update to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

drop policy if exists "Users can delete their own conversations" on public.conversations;
create policy "Users can delete their own conversations"
on public.conversations for delete to authenticated
using ((select auth.uid()) = user_id);

create index if not exists conversations_user_updated_idx
on public.conversations(user_id, updated_at desc);
